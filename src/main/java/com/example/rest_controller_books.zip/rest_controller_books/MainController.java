package com.example.rest_controller_books;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.Optional;

@Controller //This means that this class is a Controller
@RequestMapping(path=RESTNouns.VERSION_1) //This means URLs start with /v1 (after Application path)
public class MainController {
    @Autowired private AuthorRepository authorRepository;
    @Autowired private BookRepository bookRepository;

    @Autowired private AuthorIsbnRepository authorIsbnRepository;

    /**
     * Get Mapping for Author
     * @return all authors
     */
    @GetMapping(path=RESTNouns.AUTHOR)
    public @ResponseBody Iterable<Author> getAllUsers(){
        return authorRepository.findAll();
    }

    /**
     * Get Mapping for User based on ID
     * @param authorId author id
     * @return author object
     */
    @GetMapping(path = RESTNouns.AUTHOR + "/{author_id}")
    public @ResponseBody Optional<Author> getAuthorWithId(@PathVariable(name = "author_id") Integer authorId){
        return authorRepository.findById(authorId);
    }

    /**
     * Post Mapping for User
     * @param firstName first name of user
     * @param lastName last name of user
     * @return message stating success / failure
     */
    @PostMapping(path=RESTNouns.AUTHOR)
    public @ResponseBody String addNewAuthor(@RequestParam String firstName, @RequestParam String lastName){
        Author author = new Author();
        //AuthorISBN authorISBN = new AuthorISBN(); // Create an AuthorISBN
        //authorISBN.setAuthorId(authorId);
        author.setFirstName(firstName);
        author.setLastName(lastName);
        authorRepository.save(author);
        return "Successfully created new Author"; //TODO Send a better message
    }

    /**
     * Put Mapping for User based on ID
     * @param authorId author id
     * @param firstName first name update
     * @param lastName last name update
     * @return message stating success / failure
     */
    @PutMapping (path=RESTNouns.AUTHOR + "/{author_id}")
    public @ResponseBody String updateAuthor(@PathVariable(name = "author_id")  Integer authorId,
                                           @RequestParam String firstName,
                                           @RequestParam String lastName){
        Optional<Author> author = authorRepository.findById(authorId);
        if(author.isPresent()){
            author.get().setFirstName(firstName);
            author.get().setLastName(lastName);
            authorRepository.save(author.get());
            return "Updated Author Information";
        }
        return "Author not found";
    }
    /**
     * Delete Mapping for Author based on ID
     * @param authorId author id
     * @return message stating success / failure
     */
    @DeleteMapping (path=RESTNouns.AUTHOR + "/{author_id}")
    public @ResponseBody String deleteAuthor(@PathVariable(name = "author_id")  Integer authorId){
        Optional<Author> author = authorRepository.findById(authorId);
        if(author.isPresent()){
            authorRepository.delete(author.get());
            return "Author has been Deleted";
        }
        return "Author not found";
    }

    /**
     * Post Mapping for Book
     //* @param authorID author ID
     * @param isbn ISBN
     * @param title Title
     * @param editionNumber edition number
     * @param copyright Copyright
     * @return message stating success / failure
     */
    @PostMapping(path=RESTNouns.AUTHOR + "/{author_id}" + RESTNouns.BOOK)
    public @ResponseBody String addNewBook(@PathVariable(name = "author_id")  Integer authorId,
                                           @RequestParam int isbn, @RequestParam String title,
                                           @RequestParam int editionNumber, @RequestParam LocalDate copyright){
        Optional<Author> author = authorRepository.findById(authorId);
        if(author.isPresent()){
            Book book = new Book();
            book.setAuthorID(authorId);
            book.setIsbn(isbn);
            book.setTitle(title);
            book.setEditionNumber(editionNumber);
            book.setCopyright(copyright);
            book.setAuthor(author.get());
            bookRepository.save(book);
            AuthorISBN authorISBN = new AuthorISBN(); // Create an AuthorISBN
            //Optional<Author> author = authorRepository.findById(authorId);
            authorISBN.setAuthorId(authorId);
            authorISBN.setIsbn(isbn);
            authorIsbnRepository.save(authorISBN);
        }


        return "Successfully created new Book"; //TODO Send a better message
    }

    @GetMapping(path=RESTNouns.BOOK)
    public @ResponseBody Iterable<Book> getAllBooks(){
        return bookRepository.findAll();
    }

//    @GetMapping(path=RESTNouns.AUTHOR + "/{author_id}" + RESTNouns.BOOK)
//    public @ResponseBody Iterable<Book> getAllBooksByAuthor(@PathVariable(name = "author_id") Integer authorId){
//        Optional<Author> author = authorRepository.findById(authorId);
//        Iterable<Book> books = new LinkedList<>();  //Hack to build an empty list / iterable
//
//        if(author.isPresent()){
//            books = bookRepository.getAllBooksByAuthorId(author.get().getAuthorId());
//        }
//        return books;
//    }

    @DeleteMapping (path=RESTNouns.AUTHOR + "/{author_id}")
    public @ResponseBody String deleteBook(@PathVariable(name = "author_id")  Integer authorId){
        Optional<Book> author = bookRepository.findById(authorId);
        if(author.isPresent()){
            bookRepository.delete(author.get());
            return "Author has been Deleted";
        }
        return "Author not found";
    }

}
