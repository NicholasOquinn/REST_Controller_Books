package com.example.rest_controller_books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestControllerBooksApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestControllerBooksApplication.class, args);
    }

}
